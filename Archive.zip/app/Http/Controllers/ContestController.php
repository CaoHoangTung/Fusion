<?php

use App\Http\Controllers;

class ContestController extends Controller{

    public function __construct(){

    }

    public function index(){
        
    }
}