<?php

use App\Http\Controllers;

class LearnController extends Controller{

    public function __construct(){

    }

    public function index(){
        
    }
}