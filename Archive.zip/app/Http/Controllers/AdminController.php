<?php

use App\Http\Controllers;

class AdminController extends Controller{

    public function __construct(){

    }

    public function index(){
        
    }
}