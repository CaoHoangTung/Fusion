<?php

use App\Http\Controllers;

class RankingController extends Controller{

    public function __construct(){

    }

    public function index(){
        
    }
}