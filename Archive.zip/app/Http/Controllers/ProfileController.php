<?php

use App\Http\Controllers;

class ProfileController extends Controller{

    public function __construct(){

    }

    public function index(){
        
    }
}